﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Xunit;

namespace SearchByProcedureTests
{
    public class Program
    {
        [Fact]
        public void Test_ExactString()
        {
            List<String[]> test = searchByProcedure("HEART TRANSPLANT OR IMPLANT OF HEART ASSIST SYSTEM W MCC");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Split(" ")[0].Equals("001"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(81, test.Count);
        }

        [Fact]
        public void Test_ExactStringLowerCase()
        {
            List<String[]> test = searchByProcedure("heart transplant or implant of heart assist system w mcc");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Split(" ")[0].Equals("001"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(81, test.Count);
        }

        [Fact]
        public void Test_ExactStringLowerCaseWithFirstUpperCase()
        {
            List<String[]> test = searchByProcedure("Heart transplant or implant of heart assist system w mcc");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Split(" ")[0].Equals("001"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(81, test.Count);
        }

        [Fact]
        public void Test_ExactSubString()
        {
            List<String[]> test = searchByProcedure("HEART TRANSPLANT");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Split(" ")[0].Equals("001"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(81, test.Count);
        }

        [Fact]
        public void Test_AllWordsMatchingUnique()
        {
            List<String[]> test = searchByProcedure("TRANSPLANT HEART");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Split(" ")[0].Equals("001"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(81, test.Count);
        }

        [Fact]
        public void Test_WordsMatchingUnique()
        {
            List<String[]> test = searchByProcedure("I need a TRANSPLANT HEART");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!(test[i][0].Contains("HEART")|| test[i][0].Contains("TRANSPLANT")))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(47, test.Count);
        }

        [Fact]
        public void Test_AllWordsMatchingNotUnique()
        {
            List<String[]> test = searchByProcedure("HEART");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HEART"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(39, test.Count);
        }

        [Fact]
        public void Test_WordsMatchingNotUnique()
        {
            List<String[]> test = searchByProcedure("I need a HEART");
            Boolean check = true;
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HEART"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(39, test.Count);
        }


        [Fact]
        public void Test_HeartReturnsAll()
        {
            List<String[]> test = searchByProcedure("Heart");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HEART"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(39, test.Count);
        }

        [Fact]
        public void Test_LungsReturnsAll()
        {
            List<String[]> test = searchByProcedure("Lungs");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("LUNGS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(14, test.Count);
        }

        [Fact]
        public void Test_BreathingReturnsAll()
        {
            List<String[]> test = searchByProcedure("Breathing");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BREATHING"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(13, test.Count);
        }

        [Fact]
        public void Test_StrokeReturnsAll()
        {
            List<String[]> test = searchByProcedure("Stroke");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("STROKE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(8, test.Count);
        }

        [Fact]
        public void Test_BrainReturnsAll()
        {
            List<String[]> test = searchByProcedure("Brain");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BRAIN"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(20, test.Count);
        }

        [Fact]
        public void Test_SurgeryReturnsAll()
        {
            List<String[]> test = searchByProcedure("Surgery");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SURGERY"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(6, test.Count);
        }

        [Fact]
        public void Test_SpineReturnsAll()
        {
            List<String[]> test = searchByProcedure("Spine");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SPINE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(5, test.Count);
        }

        [Fact]
        public void Test_HydrocephalusReturnsAll()
        {
            List<String[]> test = searchByProcedure("Hydrocephalus");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HYDROCEPHALUS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_WaterReturnsAll()
        {
            List<String[]> test = searchByProcedure("Water");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("WATER"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(5, test.Count);
        }

        [Fact]
        public void Test_HeadReturnsAll()
        {
            List<String[]> test = searchByProcedure("Head");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HEAD"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(9, test.Count);
        }

        [Fact]
        public void Test_SkullReturnsAll()
        {
            List<String[]> test = searchByProcedure("Skull");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SKULL"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_TumorReturnsAll()
        {
            List<String[]> test = searchByProcedure("Tumor");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("TUMOR"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(18, test.Count);
        }

        [Fact]
        public void Test_NerveReturnsAll()
        {
            List<String[]> test = searchByProcedure("Nerve");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("NERVE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(12, test.Count);
        }

        [Fact]
        public void Test_SheathReturnsAll()
        {
            List<String[]> test = searchByProcedure("Sheath");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SHEATH"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_BloodReturnsAll()
        {
            List<String[]> test = searchByProcedure("Blood");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BLOOD"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(16, test.Count);
        }

        [Fact]
        public void Test_PressureReturnsAll()
        {
            List<String[]> test = searchByProcedure("Pressure");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("PRESSURE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }


        [Fact]
        public void Test_InfectionReturnsAll()
        {
            List<String[]> test = searchByProcedure("Infection");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("INFECTION"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(24, test.Count);
        }

        [Fact]
        public void Test_MigraineReturnsAll()
        {
            List<String[]> test = searchByProcedure("Migraine");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("MIGRAINE"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(236, test.Count);
        }

        [Fact]
        public void Test_EyeReturnsAll()
        {
            List<String[]> test = searchByProcedure("Eye");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("EYE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_CataractReturnsAll()
        {
            List<String[]> test = searchByProcedure("Cataract");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("CATARACT"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(1, test.Count);
        }

        [Fact]
        public void Test_OffBalanceReturnsAll()
        {
            List<String[]> test = searchByProcedure("Off-Balance");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("OFF-BALANCE"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(457, test.Count);
        }

        [Fact]
        public void Test_NosebleedReturnsAll()
        {
            List<String[]> test = searchByProcedure("Nosebleed");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("NOSEBLEED"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(5, test.Count);
        }

        [Fact]
        public void Test_EarReturnsAll()
        {
            List<String[]> test = searchByProcedure("Ear");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("EAR"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(18, test.Count);
        }

        [Fact]
        public void Test_TeethReturnsAll()
        {
            List<String[]> test = searchByProcedure("Teeth");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("TEETH"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_DiseaseReturnsAll()
        {
            List<String[]> test = searchByProcedure("Disease");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("DISEASE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(21, test.Count);
        }

        [Fact]
        public void Test_CollapsedReturnsAll()
        {
            List<String[]> test = searchByProcedure("Collapsed");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("COLLAPSED"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_SkinReturnsAll()
        {
            List<String[]> test = searchByProcedure("Skin");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SKIN"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(31, test.Count);
        }

        [Fact]
        public void Test_ArteriesReturnsAll()
        {
            List<String[]> test = searchByProcedure("Arteries");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ARTERIES"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_HeartbeatReturnsAll()
        {
            List<String[]> test = searchByProcedure("Heartbeat");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HEARTBEAT"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_FaintingReturnsAll()
        {
            List<String[]> test = searchByProcedure("Fainting");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("FAINTING"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(1655, test.Count);
        }

        [Fact]
        public void Test_IntestineReturnsAll()
        {
            List<String[]> test = searchByProcedure("Intestine");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("INTESTINE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }


        [Fact]
        public void Test_AbdomenReturnsAll()
        {
            List<String[]> test = searchByProcedure("Abdomen");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ABDOMEN"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(7, test.Count);
        }

        [Fact]
        public void Test_AppendixReturnsAll()
        {
            List<String[]> test = searchByProcedure("Appendix");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("APPENDIX"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_EsophagusReturnsAll()
        {
            List<String[]> test = searchByProcedure("Esophagus");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ESOPHAGUS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }


        [Fact]
        public void Test_BowelReturnsAll()
        {
            List<String[]> test = searchByProcedure("Bowel");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BOWEL"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(10, test.Count);
        }

        [Fact]
        public void Test_InflammationReturnsAll()
        {
            List<String[]> test = searchByProcedure("Inflammation");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("INFLAMMATION"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(8, test.Count);
        }

        [Fact]
        public void Test_LiverReturnsAll()
        {
            List<String[]> test = searchByProcedure("Liver");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("LIVER"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(21, test.Count);
        }

        [Fact]
        public void Test_GallbladderReturnsAll()
        {
            List<String[]> test = searchByProcedure("Gallbladder");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("GALLBLADDER"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(7, test.Count);
        }

        [Fact]
        public void Test_BileReturnsAll()
        {
            List<String[]> test = searchByProcedure("Bile");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BILE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }


        [Fact]
        public void Test_LumbarReturnsAll()
        {
            List<String[]> test = searchByProcedure("Lumbar");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("LUMBAR"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_LegReturnsAll()
        {
            List<String[]> test = searchByProcedure("Leg");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("LEG"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }


        [Fact]
        public void Test_ThighboneReturnsAll()
        {
            List<String[]> test = searchByProcedure("Thighbone");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("THIGHBONE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_BoneReturnsAll()
        {
            List<String[]> test = searchByProcedure("Bone");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BONE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(10, test.Count);
        }

        [Fact]
        public void Test_JointReturnsAll()
        {
            List<String[]> test = searchByProcedure("Joint");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("JOINT"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(15, test.Count);
        }

        [Fact]
        public void Test_TennisReturnsAll()
        {
            List<String[]> test = searchByProcedure("Tennis");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("TENNIS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_ElbowReturnsAll()
        {
            List<String[]> test = searchByProcedure("Elbow");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ELBOW"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(5, test.Count);
        }

        [Fact]
        public void Test_MuscleReturnsAll()
        {
            List<String[]> test = searchByProcedure("Muscle");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("MUSCLE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_WoundReturnsAll()
        {
            List<String[]> test = searchByProcedure("Wound");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("WOUND"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(7, test.Count);
        }

        [Fact]
        public void Test_HypodermisReturnsAll()
        {
            List<String[]> test = searchByProcedure("Hypodermis");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HYPODERMIS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_ProstaticReturnsAll()
        {
            List<String[]> test = searchByProcedure("Prostatic");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("PROSTATIC"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_HyperplasiaReturnsAll()
        {
            List<String[]> test = searchByProcedure("Hyperplasia");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("HYPERPLASIA"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_GrowthReturnsAll()
        {
            List<String[]> test = searchByProcedure("Growth");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("GROWTH"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_WombReturnsAll()
        {
            List<String[]> test = searchByProcedure("Womb");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("WOMB"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(8, test.Count);
        }

        [Fact]
        public void Test_VulvaReturnsAll()
        {
            List<String[]> test = searchByProcedure("Vulva");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("VULVA"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_BiopsyReturnsAll()
        {
            List<String[]> test = searchByProcedure("Biopsy");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BIOPSY"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_PeriodReturnsAll()
        {
            List<String[]> test = searchByProcedure("Period");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("PERIOD"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(1, test.Count);
        }

        [Fact]
        public void Test_CSectionReturnsAll()
        {
            List<String[]> test = searchByProcedure("C-Section");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("C-SECTION"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_BirthReturnsAll()
        {
            List<String[]> test = searchByProcedure("Birth");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("BIRTH"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(3, test.Count);
        }

        [Fact]
        public void Test_PregnancyReturnsAll()
        {
            List<String[]> test = searchByProcedure("Pregnancy");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("PREGNANCY"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_ClottingReturnsAll()
        {
            List<String[]> test = searchByProcedure("Clotting");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("CLOTTING"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(451, test.Count);
        }

        [Fact]
        public void Test_RESReturnsAll()
        {
            List<String[]> test = searchByProcedure("RES");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("RES"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(128, test.Count);
        }

        [Fact]
        public void Test_CancerReturnsAll()
        {
            List<String[]> test = searchByProcedure("Cancer");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("CANCER"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(22, test.Count);
        }

        [Fact]
        public void Test_ParasiteReturnsAll()
        {
            List<String[]> test = searchByProcedure("Parasite");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("PARASITE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_VirusReturnsAll()
        {
            List<String[]> test = searchByProcedure("Virus");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("VIRUS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_PoisoningReturnsAll()
        {
            List<String[]> test = searchByProcedure("Poisoning");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("POISONING"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(10, test.Count);
        }

        [Fact]
        public void Test_MentalReturnsAll()
        {
            List<String[]> test = searchByProcedure("Mental");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("MENTAL"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(8, test.Count);
        }

        [Fact]
        public void Test_CrazyReturnsAll()
        {
            List<String[]> test = searchByProcedure("Crazy");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("CRAZY"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(8, test.Count);
        }

        [Fact]
        public void Test_InsaneReturnsAll()
        {
            List<String[]> test = searchByProcedure("Insane");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("INSANE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(6, test.Count);
        }

        [Fact]
        public void Test_SocialReturnsAll()
        {
            List<String[]> test = searchByProcedure("Social");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("SOCIAL"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(130, test.Count);
        }

        [Fact]
        public void Test_DepressionReturnsAll()
        {
            List<String[]> test = searchByProcedure("Depression");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("DEPRESSION"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(141, test.Count);
        }

        [Fact]
        public void Test_StressReturnsAll()
        {
            List<String[]> test = searchByProcedure("Stress");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("STRESS"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_AnxietyReturnsAll()
        {
            List<String[]> test = searchByProcedure("Anxiety");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ANXIETY"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_ObsessiveReturnsAll()
        {
            List<String[]> test = searchByProcedure("Obsessive");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("OBSESSIVE"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(2, test.Count);
        }

        [Fact]
        public void Test_ImpulseReturnsAll()
        {
            List<String[]> test = searchByProcedure("Impulse");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("IMPULSE"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.True(check);
            Assert.Equal(18, test.Count);
        }

        [Fact]
        public void Test_DrunkReturnsAll()
        {
            List<String[]> test = searchByProcedure("Drunk");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("DRUNK"))
                {
                    check = false;
                }
            }
            Assert.Equal(1, test[0].Count());
            Assert.False(check);
            Assert.Equal(4, test.Count);
        }

        [Fact]
        public void Test_AllergyReturnsAll()
        {
            List<String[]> test = searchByProcedure("Allergy");
            Boolean check = true;
            List<String[]> previous = new List<string[]>();
            for (var i = 0; i < test.Count; i++)
            {
                if (!test[i][0].Contains("ALLERGY"))
                {
                    check = false;
                }
            }
            Assert.Equal(12, test[0].Count());
            Assert.False(check);
            Assert.Equal(16, test.Count);
        }

        public List<string[]> searchByProcedure(string procedure)
        {
            procedure = procedure.ToUpper();
            List<string[]> listOfOptions = new List<string[]>();
            var lines = File.ReadLines("../../res/MEDICARE_PROVIDER_CHARGE_INPATIENT_DRGALL_FY2017.txt");
            foreach (var line in lines)
            {
                string[] fields = line.Split('\t');
                string procedureFromFile = fields[0];
                procedureFromFile = procedureFromFile.Replace("\"", "");
                if (procedureFromFile.Split(" - ")[1].Equals(procedure))
                {
                    for (int i = 0; i < fields.Count(); i++)
                    {
                        fields[i] = fields[i].Replace(@"\", @"\\");
                    }
                    listOfOptions.Add(fields);
                }
            }
            List<string> searchWords = procedure.Split(" ").ToList();
            if (listOfOptions.Count == 0)
            {
                foreach (var line in lines)
                {
                    string[] fields = line.Split('\t');
                    string procedureFromFile = fields[0];
                    procedureFromFile = procedureFromFile.Replace("\"", "");
                    int count = 0;
                    foreach (string word in searchWords)
                    {
                        if (word.Length > 2)
                        {
                            if (procedureFromFile.Contains(word))
                            {
                                count++;
                            }
                        }
                    }
                    if (count == (searchWords.Count()) && count > 1)
                    {
                        for (int i = 0; i < fields.Count(); i++)
                        {
                            fields[i] = fields[i].Replace(@"\", @"\\");
                        }
                        listOfOptions.Add(fields);
                    }
                }
            }
            if (listOfOptions.Count == 0)
            {
                if (searchWords.Contains("HEART"))
                {
                    searchWords.Add("ECMO OR TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W MAJ O.R.");
                    searchWords.Add("TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W/O MAJ O.R.");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W MCC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W CC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W/O CC/MCC");
                    searchWords.Add("CAROTID ARTERY STENT PROCEDURE W CC");
                    searchWords.Add("CAROTID ARTERY STENT PROCEDURE W/O CC/MCC");
                    searchWords.Add("CORONARY BYPASS W PTCA W MCC");
                    searchWords.Add("CORONARY BYPASS W CARDIAC CATH W MCC");
                    searchWords.Add("CORONARY BYPASS W CARDIAC CATH W/O MCC");
                    searchWords.Add("CORONARY BYPASS W/O CARDIAC CATH W MCC");
                    searchWords.Add("CORONARY BYPASS W/O CARDIAC CATH W/O MCC");
                    searchWords.Add("AICD GENERATOR PROCEDURES");
                    searchWords.Add("OTHER VASCULAR PROCEDURES W MCC");
                    searchWords.Add("OTHER VASCULAR PROCEDURES W CC");
                    searchWords.Add("OTHER VASCULAR PROCEDURES W/O CC/MCC");
                    searchWords.Add("OTHER CIRCULATORY SYSTEM O.R. PROCEDURES");
                    searchWords.Add("ENDOVASCULAR CARDIAC VALVE REPLACEMENT W MCC");
                    searchWords.Add("ENDOVASCULAR CARDIAC VALVE REPLACEMENT W/O MCC");
                    searchWords.Add("OTHER MAJOR CARDIOVASCULAR PROCEDURES W MCC");
                    searchWords.Add("OTHER MAJOR CARDIOVASCULAR PROCEDURES W CC");
                    searchWords.Add("OTHER MAJOR CARDIOVASCULAR PROCEDURES W/O CC/MCC");
                    searchWords.Add("PERCUTANEOUS INTRACARDIAC PROCEDURES W MCC");
                    searchWords.Add("PERCUTANEOUS INTRACARDIAC PROCEDURES W/O MCC");
                    searchWords.Add("ACUTE MYOCARDIAL INFARCTION, DISCHARGED ALIVE W MCC");
                    searchWords.Add("ACUTE MYOCARDIAL INFARCTION, DISCHARGED ALIVE W CC");
                    searchWords.Add("ACUTE MYOCARDIAL INFARCTION, DISCHARGED ALIVE W/O CC/MCC");
                    searchWords.Add("ACUTE MYOCARDIAL INFARCTION, EXPIRED W MCC");
                    searchWords.Add("CIRCULATORY DISORDERS EXCEPT AMI, W CARD CATH W MCC");
                    searchWords.Add("CIRCULATORY DISORDERS EXCEPT AMI, W CARD CATH W/O MCC");
                    searchWords.Add("CARDIAC CONGENITAL & VALVULAR DISORDERS W MCC");
                    searchWords.Add("CARDIAC CONGENITAL & VALVULAR DISORDERS W/O MCC");
                }
                if (searchWords.Contains("LUNGS") || searchWords.Contains("LUNG"))
                {
                    searchWords.Add("ECMO OR TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W MAJ O.R.");
                    searchWords.Add("TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W/O MAJ O.R.");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W CC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W/O CC/MCC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W MCC");
                    searchWords.Add("PULMONARY EMBOLISM W MCC");
                    searchWords.Add("PULMONARY EMBOLISM W/O MCC");
                    searchWords.Add("PLEURAL EFFUSION W MCC");
                    searchWords.Add("PULMONARY EDEMA & RESPIRATORY FAILURE");
                    searchWords.Add("CHRONIC OBSTRUCTIVE PULMONARY DISEASE W MCC");
                    searchWords.Add("CHRONIC OBSTRUCTIVE PULMONARY DISEASE W CC");
                    searchWords.Add("CHRONIC OBSTRUCTIVE PULMONARY DISEASE W/O CC/MCCS");
                    searchWords.Add("PNEUMOTHORAX W MCC");
                    searchWords.Add("PNEUMOTHORAX W CC");
                    searchWords.Add("PNEUMOTHORAX W/O CC/MCC");
                }
                if (searchWords.Contains("BREATHING"))
                {
                    searchWords.Add("ECMO OR TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W MAJ O.R.");
                    searchWords.Add("TRACH W MV >96 HRS OR PDX EXC FACE, MOUTH & NECK W/O MAJ O.R.");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W CC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W/O CC/MCC");
                    searchWords.Add("TRACHEOSTOMY FOR FACE,MOUTH & NECK DIAGNOSES W MCC");
                    searchWords.Add("OTHER RESP SYSTEM O.R. PROCEDURES W MCC");
                    searchWords.Add("OTHER RESP SYSTEM O.R. PROCEDURES W CC");
                    searchWords.Add("OTHER RESP SYSTEM O.R. PROCEDURES W/O CC/MCC");
                    searchWords.Add("RESPIRATORY INFECTIONS & INFLAMMATIONS W MCC");
                    searchWords.Add("RESPIRATORY INFECTIONS & INFLAMMATIONS W CC");
                    searchWords.Add("RESPIRATORY INFECTIONS & INFLAMMATIONS W/O CC/MCC");
                    searchWords.Add("RESPIRATORY SIGNS & SYMPTOMS");
                    searchWords.Add("OTHER RESPIRATORY SYSTEM DIAGNOSES W MCC");
                }
                if (searchWords.Contains("STROKE"))
                {
                    searchWords.Add("INTRACRANIAL VASCULAR PROCEDURES W PDX HEMORRHAGE W MCC");
                    searchWords.Add("NONSPECIFIC CVA & PRECEREBRAL OCCLUSION W/O INFARCT W/O MCC");
                    searchWords.Add("TRANSIENT ISCHEMIA");
                    searchWords.Add("NONSPECIFIC CEREBROVASCULAR DISORDERS W MCC");
                    searchWords.Add("NONSPECIFIC CEREBROVASCULAR DISORDERS W CC");
                }
                if (searchWords.Contains("BRAIN"))
                {
                    searchWords.Add("CRANIOTOMY W MAJOR DEVICE IMPLANT OR ACUTE CNS PDX W MCC OR CHEMOTHE");
                    searchWords.Add("CRANIO W MAJOR DEV IMPL/ACUTE COMPLEX CNS PDX W/O MCC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W MCC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W CC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("PERIPH/CRANIAL NERVE & OTHER NERV SYST PROC W MCC");
                    searchWords.Add("PERIPH/CRANIAL NERVE & OTHER NERV SYST PROC W CC OR PERIPH NEUROSTIM");
                    searchWords.Add("PERIPH/CRANIAL NERVE & OTHER NERV SYST PROC W/O CC/MCC");
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W MCC");
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W/O MCC");
                    searchWords.Add("INTRACRANIAL HEMORRHAGE OR CEREBRAL INFARCTION W MCC");
                    searchWords.Add("INTRACRANIAL HEMORRHAGE OR CEREBRAL INFARCTION W CC OR TPA IN 24 HRS");
                    searchWords.Add("INTRACRANIAL HEMORRHAGE OR CEREBRAL INFARCTION W/O CC/MCC");
                    searchWords.Add("NONSPECIFIC CEREBROVASCULAR DISORDERS W/O CC/MCC");
                    searchWords.Add("CRANIAL & PERIPHERAL NERVE DISORDERS W MCC");
                    searchWords.Add("CRANIAL & PERIPHERAL NERVE DISORDERS W/O MCC");
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W MCC");
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W CC");
                    searchWords.Add("CRANIAL/FACIAL PROCEDURES W CC/MCC");
                    searchWords.Add("CRANIAL/FACIAL PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("SURGERY"))
                {
                    searchWords.Add("CRANIOTOMY W MAJOR DEVICE IMPLANT OR ACUTE CNS PDX W MCC OR CHEMOTHE");
                    searchWords.Add("CRANIO W MAJOR DEV IMPL/ACUTE COMPLEX CNS PDX W/O MCC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W MCC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W CC");
                    searchWords.Add("CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("EXTRAOCULAR PROCEDURES EXCEPT ORBIT");
                }
                if (searchWords.Contains("SPINE"))
                {
                    searchWords.Add("SPINAL PROCEDURES W MCC");
                    searchWords.Add("SPINAL PROCEDURES W CC OR SPINAL NEUROSTIMULATORS");
                    searchWords.Add("SPINAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("SPINAL DISORDERS & INJURIES W CC/MCC");
                    searchWords.Add("SPINAL DISORDERS & INJURIES W/O CC/MCC");
                }
                if (searchWords.Contains("HYDROCEPHALUS"))
                {
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W MCC");
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W CC");
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("WATER"))
                {
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W MCC");
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W CC");
                    searchWords.Add("VENTRICULAR SHUNT PROCEDURES W/O CC/MCC");
                    searchWords.Add("PLEURAL EFFUSION W MCC");
                    searchWords.Add("PLEURAL EFFUSION W CC");
                }
                if (searchWords.Contains("HEAD"))
                {
                    searchWords.Add("EXTRACRANIAL PROCEDURES W MCC");
                    searchWords.Add("EXTRACRANIAL PROCEDURES W CC");
                    searchWords.Add("EXTRACRANIAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("ORBITAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("OTHER EAR, NOSE, MOUTH & THROAT O.R. PROCEDURES W CC/MCC");
                }
                if (searchWords.Contains("SKULL"))
                {
                    searchWords.Add("EXTRACRANIAL PROCEDURES W MCC");
                    searchWords.Add("EXTRACRANIAL PROCEDURES W CC");
                    searchWords.Add("EXTRACRANIAL PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("TUMOR"))
                {
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W MCC");
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W/O MCC");
                    searchWords.Add("RESPIRATORY NEOPLASMS W MCC");
                    searchWords.Add("RESPIRATORY NEOPLASMS W CC");
                    searchWords.Add("KIDNEY & URETER PROCEDURES FOR NEOPLASM W MCC");
                    searchWords.Add("KIDNEY & URETER PROCEDURES FOR NEOPLASM W CC");
                    searchWords.Add("KIDNEY & URETER PROCEDURES FOR NEOPLASM W/O CC/MCC");
                    searchWords.Add("KIDNEY & URINARY TRACT NEOPLASMS W MCC");
                    searchWords.Add("KIDNEY & URINARY TRACT NEOPLASMS W CC");
                    searchWords.Add("KIDNEY & URINARY TRACT INFECTIONS W MCC");
                    searchWords.Add("KIDNEY & URINARY TRACT INFECTIONS W/O MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR OVARIAN OR ADNEXAL MALIGNANCY W MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR OVARIAN OR ADNEXAL MALIGNANCY W CC");
                    searchWords.Add("UTERINE,ADNEXA PROC FOR NON-OVARIAN/ADNEXAL MALIG W CC");
                    searchWords.Add("UTERINE,ADNEXA PROC FOR NON-OVARIAN/ADNEXAL MALIG W/O CC/MCC");
                    searchWords.Add("MALIGNANCY, FEMALE REPRODUCTIVE SYSTEM W MCC");
                    searchWords.Add("MALIGNANCY, FEMALE REPRODUCTIVE SYSTEM W CC");
                    searchWords.Add("MYELOPROLIFERATIVE DISORDERS OR POORLY");
                }
                if (searchWords.Contains("NERVE"))
                {
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W MCC");
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W/O MCC");
                    searchWords.Add("DEGENERATIVE NERVOUS SYSTEM DISORDERS W MCC");
                    searchWords.Add("DEGENERATIVE NERVOUS SYSTEM DISORDERS W/O MCC");
                    searchWords.Add("OTHER DISORDERS OF NERVOUS SYSTEM W MCC");
                    searchWords.Add("OTHER DISORDERS OF NERVOUS SYSTEM W CC");
                    searchWords.Add("OTHER DISORDERS OF NERVOUS SYSTEM W/O CC/MCC");
                }
                if (searchWords.Contains("SHEATH"))
                {
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W MCC");
                    searchWords.Add("NERVOUS SYSTEM NEOPLASMS W/O MCC");
                }
                if (searchWords.Contains("BLOOD"))
                {
                    searchWords.Add("NONSPECIFIC CEREBROVASCULAR DISORDERS W/O CC/MCC");
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W MCC");
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W CC");
                    searchWords.Add("PERIPHERAL VASCULAR DISORDERS W MCC");
                    searchWords.Add("PERIPHERAL VASCULAR DISORDERS W CC");
                    searchWords.Add("PERIPHERAL VASCULAR DISORDERS W/O CC/MCC");
                    searchWords.Add("HYPERTENSION W MCC");
                    searchWords.Add("HYPERTENSION W/O MCC");
                    searchWords.Add("MAJOR HEMATOL/IMMUN DIAG EXC SICKLE CELL CRISIS & COAGUL W MCC");
                    searchWords.Add("MAJOR HEMATOL/IMMUN DIAG EXC SICKLE CELL CRISIS & COAGUL W CC");
                    searchWords.Add("COAGULATION DISORDERS");
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W MV >96 HOURS");
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W/O MV >96 HOURS W MCC");
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W/O MV >96 HOURS W/O MCC");
                }
                if (searchWords.Contains("PRESSURE"))
                {
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W MCC");
                    searchWords.Add("HYPERTENSIVE ENCEPHALOPATHY W CC");
                    searchWords.Add("HYPERTENSION W MCC");
                    searchWords.Add("HYPERTENSION W/O MCC");
                }
                if (searchWords.Contains("INFECTION"))
                {
                    searchWords.Add("NON-BACTERIAL INFECT OF NERVOUS SYS EXC VIRAL MENINGITIS W MCC");
                    searchWords.Add("NON-BACTERIAL INFECT OF NERVOUS SYS EXC VIRAL MENINGITIS W CC");
                    searchWords.Add("OSTEOMYELITIS W MCC");
                    searchWords.Add("OSTEOMYELITIS W CC");
                    searchWords.Add("CELLULITIS W MCC");
                    searchWords.Add("CELLULITIS W/O MCC");
                    searchWords.Add("INFECTIOUS & PARASITIC DISEASES W O.R. PROCEDURE W MCC");
                    searchWords.Add("INFECTIOUS & PARASITIC DISEASES W O.R. PROCEDURE W CC");
                }
                if (searchWords.Contains("MIGRAINE"))
                {
                    searchWords.Add("HEADACHES W/O MCC");
                }
                if (searchWords.Contains("EYE"))
                {
                    searchWords.Add("ORBITAL PROCEDURES W/O CC/MCC");
                    searchWords.Add("EXTRAOCULAR PROCEDURES EXCEPT ORBIT");
                }
                if (searchWords.Contains("CATARACT"))
                {
                    searchWords.Add("INTRAOCULAR PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("OFF-BALANCE"))
                {
                    searchWords.Add("DYSEQUILIBRIUM");
                }
                if (searchWords.Contains("NOSEBLEED"))
                {
                    searchWords.Add("EPISTAXIS W/O MCC");
                }
                if (searchWords.Contains("EAR") || searchWords.Contains("EARS"))
                {
                    searchWords.Add("OTITIS MEDIA & URI W MCC");
                    searchWords.Add("OTITIS MEDIA & URI W/O MCC");
                }
                if (searchWords.Contains("TEETH") || searchWords.Contains("TOOTH"))
                {
                    searchWords.Add("DENTAL & ORAL DISEASES W MCC");
                    searchWords.Add("DENTAL & ORAL DISEASES W CC");
                }
                if (searchWords.Contains("DISEASE"))
                {
                    searchWords.Add("MYELOPROLIF DISORD OR POORLY DIFF NEOPL W MAJ O.R. PROC W CC");
                    searchWords.Add("MYELOPROLIF DISORD OR POORLY DIFF NEOPL W MAJ O.R. PROC W/O CC/MCC");
                    searchWords.Add("MYELOPROLIFERATIVE DISORDERS OR POORLY DIFFERENTIATED NEOPLASMS W OT");
                }
                if (searchWords.Contains("COLLAPSED"))
                {
                    searchWords.Add("PNEUMOTHORAX W MCC");
                    searchWords.Add("PNEUMOTHORAX W CC");
                    searchWords.Add("PNEUMOTHORAX W/O CC/MCC");
                }
                if (searchWords.Contains("SKIN"))
                {
                    searchWords.Add("PERCUTANEOUS INTRACARDIAC PROCEDURES W MCC");
                    searchWords.Add("PERCUTANEOUS INTRACARDIAC PROCEDURES W/O MCC");
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W MCC");
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W CC");
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W/O CC/MCC");
                    searchWords.Add("CELLULITIS W MCC");
                    searchWords.Add("CELLULITIS W/O MCC");
                }
                if (searchWords.Contains("ARTERIES"))
                {
                    searchWords.Add("ATHEROSCLEROSIS W MCC");
                    searchWords.Add("ATHEROSCLEROSIS W/O MCC");
                }
                if (searchWords.Contains("HEARTBEAT"))
                {
                    searchWords.Add("CARDIAC ARRHYTHMIA & CONDUCTION DISORDERS W MCC");
                    searchWords.Add("CARDIAC ARRHYTHMIA & CONDUCTION DISORDERS W CC");
                    searchWords.Add("CARDIAC ARRHYTHMIA & CONDUCTION DISORDERS W/O CC/MCC");
                }
                if (searchWords.Contains("FAINTING"))
                {
                    searchWords.Add("SYNCOPE & COLLAPSE");
                }
                if (searchWords.Contains("INTESTINE"))
                {
                    searchWords.Add("STOMACH, ESOPHAGEAL & DUODENAL PROC W MCC");
                    searchWords.Add("STOMACH, ESOPHAGEAL & DUODENAL PROC W CC");
                    searchWords.Add("STOMACH, ESOPHAGEAL & DUODENAL PROC W/O CC/MCC");
                }
                if (searchWords.Contains("ABDOMEN"))
                {
                    searchWords.Add("PERITONEAL ADHESIOLYSIS W MCC");
                    searchWords.Add("PERITONEAL ADHESIOLYSIS W CC");
                    searchWords.Add("PERITONEAL ADHESIOLYSIS W/O CC/MCC");
                    searchWords.Add("MAJOR GASTROINTESTINAL DISORDERS & PERITONEAL INFECTIONS W MCC");
                    searchWords.Add("MAJOR GASTROINTESTINAL DISORDERS & PERITONEAL INFECTIONS W CC");
                    searchWords.Add("MAJOR GASTROINTESTINAL DISORDERS & PERITONEAL INFECTIONS W/O CC/MCC");
                    searchWords.Add("D&C, CONIZATION, LAPAROSCOPY & TUBAL INTERRUPTION W CC/MCC");
                }
                if (searchWords.Contains("APPENDIX"))
                {
                    searchWords.Add("APPENDECTOMY W COMPLICATED PRINCIPAL DIAG W CC");
                    searchWords.Add("APPENDECTOMY W COMPLICATED PRINCIPAL DIAG W/O CC/MCC");
                    searchWords.Add("APPENDECTOMY W/O COMPLICATED PRINCIPAL DIAG W/O CC/MCC");
                }
                if (searchWords.Contains("ESOPHAGUS"))
                {
                    searchWords.Add("MAJOR ESOPHAGEAL DISORDERS W MCC");
                    searchWords.Add("MAJOR ESOPHAGEAL DISORDERS W CC");
                    searchWords.Add("ESOPHAGITIS, GASTROENT & MISC DIGEST DISORDERS W MCC");
                }
                if (searchWords.Contains("BOWEL"))
                {
                    searchWords.Add("G.I. OBSTRUCTION W MCC");
                    searchWords.Add("G.I. OBSTRUCTION W CC");
                    searchWords.Add("G.I. OBSTRUCTION W/O CC/MCC");
                }
                if (searchWords.Contains("INFLAMMATION"))
                {
                    searchWords.Add("ESOPHAGITIS, GASTROENT & MISC DIGEST DISORDERS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W/O MCC");
                }
                if (searchWords.Contains("LIVER"))
                {
                    searchWords.Add("BILIARY TRACT PROC EXCEPT ONLY CHOLECYST W OR W/O C.D.E. W MCC");
                    searchWords.Add("HEPATOBILIARY DIAGNOSTIC PROCEDURES W MCC");
                    searchWords.Add("OTHER HEPATOBILIARY OR PANCREAS O.R. PROCEDURES W MCC");
                    searchWords.Add("CIRRHOSIS & ALCOHOLIC HEPATITIS W MCC");
                    searchWords.Add("CIRRHOSIS & ALCOHOLIC HEPATITIS W CC");
                    searchWords.Add("MALIGNANCY OF HEPATOBILIARY SYSTEM OR PANCREAS W MCC");
                    searchWords.Add("MALIGNANCY OF HEPATOBILIARY SYSTEM OR PANCREAS W CC");
                    searchWords.Add("MALIGNANCY OF HEPATOBILIARY SYSTEM OR PANCREAS W/O CC/MCC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W MCC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W CC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W/O CC/MCC");
                }
                if (searchWords.Contains("GALLBLADDER"))
                {
                    searchWords.Add("BILIARY TRACT PROC EXCEPT ONLY CHOLECYST W OR W/O C.D.E. W MCC");
                    searchWords.Add("CHOLECYSTECTOMY EXCEPT BY LAPAROSCOPE W/O C.D.E. W MCC");
                    searchWords.Add("CHOLECYSTECTOMY EXCEPT BY LAPAROSCOPE W/O C.D.E. W CC");
                    searchWords.Add("CHOLECYSTECTOMY EXCEPT BY LAPAROSCOPE W/O C.D.E. W/O CC/MCC");
                    searchWords.Add("LAPAROSCOPIC CHOLECYSTECTOMY W/O C.D.E. W MCC");
                    searchWords.Add("LAPAROSCOPIC CHOLECYSTECTOMY W/O C.D.E. W CC");
                    searchWords.Add("LAPAROSCOPIC CHOLECYSTECTOMY W/O C.D.E. W/O CC/MCC");
                }
                if (searchWords.Contains("BILE"))
                {
                    searchWords.Add("BILIARY TRACT PROC EXCEPT ONLY CHOLECYST W OR W/O C.D.E. W MCC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W MCC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W CC");
                    searchWords.Add("DISORDERS OF THE BILIARY TRACT W/O CC/MCC");
                }
                if (searchWords.Contains("LUMBAR"))
                {
                    searchWords.Add("COMBINED ANTERIOR/POSTERIOR SPINAL FUSION W MCC");
                    searchWords.Add("COMBINED ANTERIOR/POSTERIOR SPINAL FUSION W CC");
                    searchWords.Add("COMBINED ANTERIOR/POSTERIOR SPINAL FUSION W/O CC/MCC");
                }
                if (searchWords.Contains("LEG"))
                {
                    searchWords.Add("BILATERAL OR MULTIPLE MAJOR JOINT PROCS OF LOWER EXTREMITY W/O MCC");
                    searchWords.Add("LOWER EXTREM & HUMER PROC EXCEPT HIP,FOOT,FEMUR W MCC");
                    searchWords.Add("LOWER EXTREM & HUMER PROC EXCEPT HIP,FOOT,FEMUR W CC");
                    searchWords.Add("LOWER EXTREM & HUMER PROC EXCEPT HIP,FOOT,FEMUR W/O CC/MCC");
                }
                if (searchWords.Contains("GRAFT"))
                {
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W MCC");
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W CC");
                    searchWords.Add("WND DEBRID & SKN GRFT EXC HAND, FOR MUSCULO-CONN TISS DIS W/O CC/MCC");
                }
                if (searchWords.Contains("THIGHBONE"))
                {
                    searchWords.Add("HIP & FEMUR PROCEDURES EXCEPT MAJOR JOINT W MCC");
                    searchWords.Add("HIP & FEMUR PROCEDURES EXCEPT MAJOR JOINT W CC");
                    searchWords.Add("HIP & FEMUR PROCEDURES EXCEPT MAJOR JOINT W/O CC/MCC");
                    searchWords.Add("LOCAL EXCISION & REMOVAL INT FIX DEVICES OF HIP & FEMUR W CC/MCC");
                }
                if (searchWords.Contains("BONE"))
                {
                    searchWords.Add("OSTEOMYELITIS W MCC");
                    searchWords.Add("OSTEOMYELITIS W CC");
                    searchWords.Add("MYELOPROLIF DISORD OR POORLY DIFF NEOPL W MAJ O.R. PROC W CC");
                    searchWords.Add("MYELOPROLIF DISORD OR POORLY DIFF NEOPL W MAJ O.R. PROC W/O CC/MCC");
                    searchWords.Add("MYELOPROLIFERATIVE DISORDERS OR POORLY DIFFERENTIATED NEOPLASMS W OT");
                }
                if (searchWords.Contains("JOINT"))
                {
                    searchWords.Add("BONE DISEASES & ARTHROPATHIES W/O MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W/O MCC");
                }
                if (searchWords.Contains("TENNIS"))
                {
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W/O MCC");
                }
                if (searchWords.Contains("ELBOW"))
                {
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W/O MCC");
                }
                if (searchWords.Contains("MUSCLE"))
                {
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W MCC");
                    searchWords.Add("TENDONITIS, MYOSITIS & BURSITIS W/O MCC");
                    searchWords.Add("BENIGN PROSTATIC HYPERTROPHY W/O MCC");
                }
                if (searchWords.Contains("WOUND"))
                {
                    searchWords.Add("SKIN DEBRIDEMENT W MCC");
                    searchWords.Add("SKIN DEBRIDEMENT W CC");
                }
                if (searchWords.Contains("HYPODERMIS"))
                {
                    searchWords.Add("OTHER SKIN, SUBCUT TISS & BREAST PROC W/O CC/MCC");
                    searchWords.Add("TRAUMA TO THE SKIN, SUBCUT TISS & BREAST W MCC");
                    searchWords.Add("TRAUMA TO THE SKIN, SUBCUT TISS & BREAST W/O MCC");
                }
                if (searchWords.Contains("KIDNEY"))
                {
                    searchWords.Add("ADRENAL & PITUITARY PROCEDURES W CC/MCC");
                    searchWords.Add("ADRENAL & PITUITARY PROCEDURES W/O CC/MCC");
                    searchWords.Add("RENAL FAILURE W MCC");
                    searchWords.Add("RENAL FAILURE W CC");
                    searchWords.Add("RENAL FAILURE W/O CC/MCC");
                    searchWords.Add("URINARY STONES W/O ESW LITHOTRIPSY W MCC");
                    searchWords.Add("URINARY STONES W/O ESW LITHOTRIPSY W/O MCC");
                }
                if (searchWords.Contains("SISTRUNK"))
                {
                    searchWords.Add("THYROID, PARATHYROID & THYROGLOSSAL PROCEDURES W CC");
                    searchWords.Add("THYROID, PARATHYROID & THYROGLOSSAL PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("HORMONES"))
                {
                    searchWords.Add("OTHER ENDOCRINE, NUTRIT & METAB O.R. PROC W CC");
                    searchWords.Add("ENDOCRINE DISORDERS W MCC");
                    searchWords.Add("ENDOCRINE DISORDERS W CC");
                    searchWords.Add("ENDOCRINE DISORDERS W/O CC/MCC");
                }
                if (searchWords.Contains("PROSTATIC"))
                {
                    searchWords.Add("TRANSURETHRAL PROCEDURES W MCC");
                    searchWords.Add("TRANSURETHRAL PROCEDURES W CC");
                    searchWords.Add("TRANSURETHRAL PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("HYPERPLASIA"))
                {
                    searchWords.Add("TRANSURETHRAL PROCEDURES W MCC");
                    searchWords.Add("TRANSURETHRAL PROCEDURES W CC");
                    searchWords.Add("TRANSURETHRAL PROCEDURES W/O CC/MCC");
                }
                if (searchWords.Contains("GROWTH"))
                {
                    searchWords.Add("BENIGN PROSTATIC HYPERTROPHY W/O MCC");
                }
                if (searchWords.Contains("WOMB"))
                {
                    searchWords.Add("PELVIC EVISCERATION, RAD HYSTERECTOMY & RAD VULVECTOMY W CC/MCC");
                    searchWords.Add("PELVIC EVISCERATION, RAD HYSTERECTOMY & RAD VULVECTOMY W/O CC/MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR OVARIAN OR ADNEXAL MALIGNANCY W MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR OVARIAN OR ADNEXAL MALIGNANCY W CC");
                    searchWords.Add("UTERINE,ADNEXA PROC FOR NON-OVARIAN/ADNEXAL MALIG W CC");
                    searchWords.Add("UTERINE,ADNEXA PROC FOR NON-OVARIAN/ADNEXAL MALIG W/O CC/MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR NON-MALIGNANCY W CC/MCC");
                    searchWords.Add("UTERINE & ADNEXA PROC FOR NON-MALIGNANCY W/O CC/MCC");
                }
                if (searchWords.Contains("BIOPSY"))
                {
                    searchWords.Add("D&C, CONIZATION, LAPAROSCOPY & TUBAL INTERRUPTION W CC/MCC");
                }
                if (searchWords.Contains("VULVA"))
                {
                    searchWords.Add("PELVIC EVISCERATION, RAD HYSTERECTOMY & RAD VULVECTOMY W CC/MCC");
                    searchWords.Add("PELVIC EVISCERATION, RAD HYSTERECTOMY & RAD VULVECTOMY W/O CC/MCC");
                }
                if (searchWords.Contains("PERIOD"))
                {
                    searchWords.Add("MENSTRUAL & OTHER FEMALE REPRODUCTIVE SYSTEM DISORDERS W CC/MCC");
                }
                if (searchWords.Contains("C-SECTION"))
                {
                    searchWords.Add("CESAREAN SECTION W CC/MCC");
                    searchWords.Add("CESAREAN SECTION W/O CC/MCC");
                }
                if (searchWords.Contains("BIRTH"))
                {
                    searchWords.Add("VAGINAL DELIVERY W COMPLICATING DIAGNOSES");
                    searchWords.Add("VAGINAL DELIVERY W/O COMPLICATING DIAGNOSES");
                    searchWords.Add("OTHER ANTEPARTUM DIAGNOSES W MEDICAL COMPLICATIONS");
                }
                if (searchWords.Contains("PREGNANCY"))
                {
                    searchWords.Add("VAGINAL DELIVERY W COMPLICATING DIAGNOSES");
                    searchWords.Add("VAGINAL DELIVERY W/O COMPLICATING DIAGNOSES");
                }
                if (searchWords.Contains("CLOTTING"))
                {
                    searchWords.Add("COAGULATION DISORDERS");
                }
                if (searchWords.Contains("RES"))
                {
                    searchWords.Add("RETICULOENDOTHELIAL & IMMUNITY DISORDERS W MCC");
                    searchWords.Add("RETICULOENDOTHELIAL & IMMUNITY DISORDERS W CC");
                    searchWords.Add("RETICULOENDOTHELIAL & IMMUNITY DISORDERS W/O CC/MCC");
                }
                if (searchWords.Contains("CANCER"))
                {
                    searchWords.Add("DIGESTIVE MALIGNANCY W MCC");
                    searchWords.Add("DIGESTIVE MALIGNANCY W CC");
                    searchWords.Add("MALIGNANT BREAST DISORDERS W MCC");
                    searchWords.Add("MALIGNANT BREAST DISORDERS W CC");
                    searchWords.Add("LYMPHOMA & LEUKEMIA W MAJOR O.R. PROCEDURE W MCC");
                    searchWords.Add("LYMPHOMA & LEUKEMIA W MAJOR O.R. PROCEDURE W CC");
                    searchWords.Add("LYMPHOMA & LEUKEMIA W MAJOR O.R. PROCEDURE W/O CC/MCC");
                    searchWords.Add("LYMPHOMA & NON-ACUTE LEUKEMIA W OTHER PROC W MCC");
                    searchWords.Add("LYMPHOMA & NON-ACUTE LEUKEMIA W OTHER O.R. PROC W CC");
                    searchWords.Add("ACUTE LEUKEMIA W/O MAJOR O.R. PROCEDURE W MCC");
                    searchWords.Add("ACUTE LEUKEMIA W/O MAJOR O.R. PROCEDURE W CC");
                    searchWords.Add("CHEMO W ACUTE LEUKEMIA AS SDX OR W HIGH DOSE CHEMO AGENT W MCC");
                    searchWords.Add("CHEMO W ACUTE LEUKEMIA AS SDX W CC OR HIGH DOSE CHEMO AGENT");
                    searchWords.Add("CHEMO W ACUTE LEUKEMIA AS SDX W/O CC/MCC");
                    searchWords.Add("LYMPHOMA & NON-ACUTE LEUKEMIA W MCC");
                    searchWords.Add("LYMPHOMA & NON-ACUTE LEUKEMIA W CC");
                    searchWords.Add("LYMPHOMA & NON-ACUTE LEUKEMIA W/O CC/MCC");
                    searchWords.Add("OTHER MYELOPROLIF DIS OR POORLY DIFF NEOPL DIAG W MCC");
                    searchWords.Add("OTHER MYELOPROLIF DIS OR POORLY DIFF NEOPL DIAG W CC");
                    searchWords.Add("CHEMOTHERAPY W/O ACUTE LEUKEMIA AS SECONDARY DIAGNOSIS W MCC");
                    searchWords.Add("CHEMOTHERAPY W/O ACUTE LEUKEMIA AS SECONDARY DIAGNOSIS W CC");
                    searchWords.Add("849 - RADIOTHERAPY");
                }
                if (searchWords.Contains("PARASITE"))
                {
                    searchWords.Add("INFECTIOUS & PARASITIC DISEASES W O.R. PROCEDURE W MCC");
                    searchWords.Add("INFECTIOUS & PARASITIC DISEASES W O.R. PROCEDURE W CC");
                }
                if (searchWords.Contains("VIRUS"))
                {
                    searchWords.Add("VIRAL ILLNESS W MCC");
                    searchWords.Add("VIRAL ILLNESS W/O MCC");
                }
                if (searchWords.Contains("POISONING"))
                {
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W MV >96 HOURS");
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W/O MV >96 HOURS W MCC");
                    searchWords.Add("SEPTICEMIA OR SEVERE SEPSIS W/O MV >96 HOURS W/O MCC");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE, LEFT AMA");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W REHABILITATION THERAPY");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W/O ");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W/O REHABILITATION THERAPY W/O MCC");
                }
                if (searchWords.Contains("MENTAL"))
                {
                    searchWords.Add("ACUTE ADJUSTMENT REACTION & PSYCHOSOCIAL DYSFUNCTION");
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                    searchWords.Add("DISORDERS OF PERSONALITY & IMPULSE CONTROL");
                    searchWords.Add("ORGANIC DISTURBANCES & INTELLECTUAL DISABILITY");
                    searchWords.Add("PSYCHOSES");
                }
                if (searchWords.Contains("CRAZY"))
                {
                    searchWords.Add("O.R. PROCEDURE W PRINCIPAL DIAGNOSES OF MENTAL ILLNESS");
                    searchWords.Add("ACUTE ADJUSTMENT REACTION & PSYCHOSOCIAL DYSFUNCTION");
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                    searchWords.Add("DISORDERS OF PERSONALITY & IMPULSE CONTROL");
                    searchWords.Add("ORGANIC DISTURBANCES & INTELLECTUAL DISABILITY");
                    searchWords.Add("PSYCHOSES");
                    searchWords.Add("OTHER MENTAL DISORDER DIAGNOSES");
                }
                if (searchWords.Contains("INSANE"))
                {
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                    searchWords.Add("DISORDERS OF PERSONALITY & IMPULSE CONTROL");
                    searchWords.Add("ORGANIC DISTURBANCES & INTELLECTUAL DISABILITY");
                    searchWords.Add("PSYCHOSES");
                    searchWords.Add("OTHER MENTAL DISORDER DIAGNOSES");
                }
                if (searchWords.Contains("SOCIAL"))
                {
                    searchWords.Add("ACUTE ADJUSTMENT REACTION & PSYCHOSOCIAL DYSFUNCTION");
                }
                if (searchWords.Contains("DEPRESSION"))
                {
                    searchWords.Add("DEPRESSIVE NEUROSES");
                }
                if (searchWords.Contains("STRESS"))
                {
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                }
                if (searchWords.Contains("ANXIETY"))
                {
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                }
                if (searchWords.Contains("OBSESSIVE"))
                {
                    searchWords.Add("DEPRESSIVE NEUROSES");
                    searchWords.Add("NEUROSES EXCEPT DEPRESSIVE");
                }
                if (searchWords.Contains("DRUNK"))
                {
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE, LEFT AMA");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W REHABILITATION THERAPY");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W/O REHABILITATION THERAPY W MCC");
                    searchWords.Add("ALCOHOL/DRUG ABUSE OR DEPENDENCE W/O REHABILITATION THERAPY W/O MCC");
                }
                if (searchWords.Contains("ALLERGY"))
                {
                    searchWords.Add("ALLERGIC REACTIONS W/O MCC");
                }

                foreach (var line in lines)
                {
                    string[] fields = line.Split('\t');
                    string procedureFromFile = fields[0];
                    procedureFromFile = procedureFromFile.Replace("\"", "");
                    int count = 0;
                    foreach (string word in searchWords)
                    {
                        if (word.Length > 2)
                        {
                            if (procedureFromFile.Contains(word))
                            {
                                count++;
                            }
                        }
                    }
                    if (count == (searchWords.Count()))
                    {
                        for (int i = 0; i < fields.Count(); i++)
                        {
                            fields[i] = fields[i].Replace(@"\", @"\\");
                        }
                        listOfOptions.Add(fields);
                    }
                }
            }
            if (listOfOptions.Count == 0)
            {
                foreach (var line in lines)
                {
                    string[] fields = line.Split('\t');
                    string procedureFromFile = fields[0];
                    procedureFromFile = procedureFromFile.Replace("\"", "");
                    int count = 0;
                    foreach (string word in searchWords)
                    {
                        if (word.Length > 2)
                        {
                            if (procedureFromFile.Contains(word))
                            {
                                count++;
                            }
                        }
                    }
                    if (count >= 1)
                    {
                        for (int i = 0; i < fields.Count(); i++)
                        {
                            fields[i] = fields[i].Replace(@"\", @"\\");
                        }
                        listOfOptions.Add(fields);
                    }
                }
            }
            string code = listOfOptions[0][0].Split(" ")[0];
            bool check = true;
            //string[] num = new string[] {"003", "004", "005", "006", "011", "012", "013", "014", "016", "017", "023", "024", "025", "026", "027", "028", "029", "030", "031", "032", "033", "035", "036", "037", "038", "039", "040", "041", "042", "052", "053", "054", "055", "056", "057", "058", "059", "060", "061", "062", "063", "064", "065", "066", "070", "071", "072", "073", "074", "077", "008", "082", "083", "084", "085", "086", "087", "088", "090", "091", "092", "093", "097", "098", "100", "101", "129", "130", "131", "132", "152", "153", "154", "155", "156", "157", "158", "163", "164", "165", "166", "167", "168", "175", "176", "177", "178", "179", "180", "181", "183", "184", "185", "186", "187", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "205", "206", "207", "208", "216", "217", "219", "220", "221", "222", "224", "225", "226", "227", "228", "229", "231", "233", "234", "235", "236", "239", "240", "242", "243", "244", "246", "247", "248", "249", "250", "251", "252", "253", "254", "255", "256", "260", "261", "262", "266", "267", "268", "269", "270", "271", "272", "273", "274", "280", "281", "282", "283", "286", "287", "291", "292", "293", "299", "300", "301", "302", "303", "304", "305", "306", "307", "308", "309", "310", "314", "315", "316", "326", "327", "328", "329", "330", "331", "335", "336", "337", "339", "340", "343", "351", "352", "353", "354", "355", "356", "357", "368", "369", "371", "372", "373", "374", "375", "377", "378", "379", "380", "381", "384", "385", "386", "387", "388", "389", "390", "391", "392", "393", "394", "395", "405", "406", "407", "414", "415", "416", "417", "418", "419", "432", "433", "435", "436", "437", "438", "439", "440", "441", "442", "443", "444", "445", "446", "453", "454", "455", "456", "457", "458", "459", "460", "463", "464", "465", "466", "467", "468", "471", "472", "473", "474", "475", "477", "478", "479", "480", "481", "482", "488", "489", "492", "493", "494", "496", "497", "500", "501", "502", "510", "511", "512", "513", "514", "515", "516", "517", "518", "519", "520", "535", "536", "539", "540", "542", "543", "544", "545", "546", "547", "551", "552", "553", "554", "555", "556", "557", "558", "559", "560", "561", "562", "563", "564", "565", "570", "571", "573", "574", "577", "578", "579", "580", "581", "592", "593", "595", "596", "597", "598", "602", "603", "604", "605", "606", "607", "614", "615", "616", "617", "619", "620", "621", "622", "623", "624", "626", "627", "628", "629", "637", "638", "639", "640", "641", "643", "644", "645", "653", "654", "655", "656", "657", "658", "659", "660", "668", "669", "670", "673", "674", "682", "683", "684", "686", "687", "689", "690", "693", "694", "698", "699", "700", "707", "708", "713", "714", "717", "718", "727", "728", "734", "735", "736", "737", "740", "741", "742", "743", "746", "747", "754", "755", "765", "766", "774", "775", "808", "809", "811", "812", "814", "815", "816", "820", "821", "822", "823", "824", "827", "828", "829", "834", "835", "837", "838", "839", "840", "841", "842", "843", "844", "846", "847", "853", "854", "856", "857", "862", "863", "865", "866", "867", "868", "869", "870", "871", "872", "894", "895", "896", "897", "901", "902", "907", "908", "909", "917", "918", "919", "920", "921", "928", "929", "934", "940", "941", "945", "946", "947", "948", "949", "950", "957", "958", "963", "964", "974", "975", "977", "981", "982", "983", "987", "988", "989"};
            for (var i = 0; i < listOfOptions.Count; i++)
            {
                if (!listOfOptions[i][0].Split(" ")[0].Equals(code))// && !num.Contains(listOfOptions[i][0].Split(" ")[0]))
                {
                    check = false;
                }
            }
            if (check == true)
            {
                List<String[]> previous = new List<string[]>();
                for (var i = listOfOptions.Count - 1; i >= 0; i--)
                {
                    foreach (string[] row in previous)
                    {
                        if (listOfOptions[i][2].Equals(row[2]))
                        {
                            listOfOptions.RemoveAt(i);
                        }
                    }

                    previous.Add(listOfOptions[i]);
                }
                return listOfOptions;
            }
            else
            {
                List<string[]> temp = new List<string[]>();
                foreach (string[] option in listOfOptions)
                {
                    temp.Add(option);
                }
                listOfOptions.Clear();
                String previous2 = "";

                for (var i = 0; i < temp.Count; i++)
                {
                    string[] test = new string[1] {temp[i][0]};
                    if (!temp[i][0].Equals(previous2)) {
                        listOfOptions.Add(test);
                    }
                    previous2 = temp[i][0];
                }
                return listOfOptions;
            }
        }

    }
}
