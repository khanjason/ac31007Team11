﻿using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace SortByDistance
{
    public class Program
    {
        
        [Fact]
        public void Test_Sort_by_Distance()
        {
            List<String[]> expected = new List<String[]>{
            new []{"025 - CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W MCC", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE","DOTHAN","AL","36301","AL - Dothan","32","98357.5625","20688.34375","19791.40625","10.5"},
            new []{"023 - CRANIOTOMY W MAJOR DEVICE IMPLANT OR ACUTE CNS PDX W MCC OR CHEMOTHE", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE","DOTHAN","AL","36301","AL - Dothan","28","117117.7857","25823.71429","24057.39286","78.5"},
            new []{"027 - CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W/O CC/MCC", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE", "DOTHAN", "AL","36301","AL - Dothan","11","69153.54546","11811.18182","8194.363636","200.6"},
            };
            List<String[]> actual = Sort_by_Distance();
            Assert.Equal(expected, actual);

        }
        

        public List<String[]> Sort_by_Distance()
        {
            List<string[]> DetailList = new List<String[]>{
            new []{"023 - CRANIOTOMY W MAJOR DEVICE IMPLANT OR ACUTE CNS PDX W MCC OR CHEMOTHE", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE","DOTHAN","AL","36301","AL - Dothan","28","117117.7857","25823.71429","24057.39286","78.5"},
            new []{"027 - CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W/O CC/MCC", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE", "DOTHAN", "AL","36301","AL - Dothan","11","69153.54546","11811.18182","8194.363636","200.6"},
            new []{"025 - CRANIOTOMY & ENDOVASCULAR INTRACRANIAL PROCEDURES W MCC", "10001", "SOUTHEAST ALABAMA MEDICAL CENTER","1108 ROSS CLARK CIRCLE","DOTHAN","AL","36301","AL - Dothan","32","98357.5625","20688.34375","19791.40625","10.5"},

            };


            DetailList = DetailList.OrderBy(arr => Double.Parse(arr[12])).ToList();
            return DetailList;
        }
    }
}
